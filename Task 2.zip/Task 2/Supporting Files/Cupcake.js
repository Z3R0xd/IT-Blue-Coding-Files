

function check()
{
var x=NumCakes.value
//These variables contain the amount of ingredients for 6 cakes
var Butter=120
var Sugar=120
var Flour=120
var Eggs=1
var Extract=0.5


