function Animate()
{

setInterval(Timer, 1000); //This will call the Timer function - units are milliseconds

	function Timer()// Complete the Timer() function by adding conditional statements to display the images
	{
		
	

