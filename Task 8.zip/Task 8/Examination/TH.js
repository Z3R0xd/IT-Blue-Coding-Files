
function calculate() 

 {
  var AngleFactor = Math.tan(angle.value * Math.PI / 180);
  // Complete the calculation.
  //Height of tree = (AngleFactor*Distance from tree)+Eye height of the viewer
  var height,d,eye_height
  d=Number(distance.value) //Number function will help convert the value to a number... duh
  eye_height=Number(viewheight.value)
  height=(AngleFactor*d)+eye_height
  h=height.toFixed(1) //.toFixed will round the result to 1 decimal place
  document.getElementById("Treeheight Result").innerHTML="The height of the tree is "+h+" metres"
 }

 function cleardata()
 {
    location.reload() //This will reload the page so that users can enter new data
 }